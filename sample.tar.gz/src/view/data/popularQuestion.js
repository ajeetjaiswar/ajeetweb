const popularQuestion = [
    {
        profileImage:'https://i0.wp.com/zblogged.com/wp-content/uploads/2019/02/FakeDP.jpeg?resize=567%2C580&ssl=1',
        userName:'Shyama Lehri',
        hashTag:[
            {
                tagName:'#jobs',
                tagLink: 'Link text'
            },
            {
                tagName:'#designjobs',
                tagLink: 'Link text'
            },
            {
                tagName:'#hrexecutive',
                tagLink: 'Link text'
            }
        ],
        question:'I want to switch job role in my current organisation? Can any one help? Thanks!'
    },
    {
        profileImage:'https://twistedsifter.files.wordpress.com/2012/09/trippy-profile-pic-portrait-head-on-and-from-side-angle.jpg?w=800',
        userName:'Pulkit Aggrawal',
        hashTag:[
            {
                tagName:'#jobs',
                tagLink: 'Link text'
            },
            {
                tagName:'#designjobs',
                tagLink: 'Link text'
            },
            {
                tagName:'#fresher',
                tagLink: 'Link text'
            }
        ],
        question:'I want to switch job role in my current organisation? Can any one help? Thanks!'
    }
]
export default popularQuestion;
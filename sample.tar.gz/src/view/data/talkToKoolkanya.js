  const talkToKoolkanya = [
    {
        profileImage:'https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg-1024x683.jpg',
        userName:'Anindita Guha',
        designation:'HR Head',
        idUlr:'Anindita Guha'
    },
    {
        profileImage:'https://i0.wp.com/zblogged.com/wp-content/uploads/2019/02/FakeDP.jpeg?resize=567%2C580&ssl=1',
        userName:'Shyama Lehri',
        designation:'Ios Devloper',
        idUlr:'Shyama Lehri'
    }
]
export default talkToKoolkanya;
export const feed = [
    {
        content: 'This is my conente',
        author: 'name',
        comments: [{
            content: 'Comment content'
        }],
        date: '2018-09-11',
        resource: {
            // link: [
            //     {
            //         url: 'https://helpx.adobe.com/',
            //         meta: {
            //             title: 'Here goes the article title and some copy attached to it | this is a link',
            //             thumbNail: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            //         },
            //     },
            // ],
            videoUrl: [


            ],
            image: [
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            ]
        },
        tagIds: ['string'],
        // like: {
        //     author: user_id,
        //     date: { type: Date, default: Date.now }
        // },
        // status: boolean
    },
    {
        content: 'This is my conente',
        author: 'name',
        comments: [{
            content: 'Comment content'
        }],
        date: '2018-09-11',
        resource: {
            // link: [
            //     {
            //         url: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            //         meta: {
            //             title: 'Here goes the article title and some copy attached to it | this is a link',
            //             thumbNail: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            //         },
            //     },
            // ],
            videoUrl: [
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=0cGj4prWlFk&list=RDMMzdXiSlRrgWQ&index=3'
                },
            ],
            image: [
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            ]
        },
        tagIds: ['string'],
        // like: {
        //     author: user_id,
        //     date: { type: Date, default: Date.now }
        // },
        // status: boolean
    },
    {
        content: 'This is my conente',
        author: 'name',
        comments: [{
            content: 'Comment content'
        }],
        date: '2018-09-11',
        resource: {
            // link: [
            //     {
            //         url: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            //         meta: {
            //             title: 'Here goes the article title and some copy attached to it | this is a link',
            //             thumbNail: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            //         },
            //     },
            // ],
            videoUrl: [
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=LMnJp_dSdnw&list=RDLMnJp_dSdnw&start_radio=1'
                },
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=LMnJp_dSdnw&list=RDLMnJp_dSdnw&start_radio=1'
                },
            ],
            image: [
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            ]
        },
        tagIds: ['string'],
        // like: {
        //     author: user_id,
        //     date: { type: Date, default: Date.now }
        // },
        // status: boolean
    },
     {
        content: 'This is my conente',
        author: 'name',
        comments: [{
            content: 'Comment content'
        }],
        date: '2018-09-11',
        resource: {
            // link: [
            //     {
            //         url: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            //         meta: {
            //             title: 'Here goes the article title and some copy attached to it | this is a link',
            //             thumbNail: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            //         },
            //     },
            // ],
            videoUrl: [
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=zdXiSlRrgWQ&list=RDMMzdXiSlRrgWQ&start_radio=1'
                },
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=zdXiSlRrgWQ&list=RDMMzdXiSlRrgWQ&start_radio=1'
                },
            ],
            image: [
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            ]
        },
        tagIds: ['string'],
        // like: {
        //     author: user_id,
        //     date: { type: Date, default: Date.now }
        // },
        // status: boolean
    },
    {
        content: 'This is my conente',
        author: 'name',
        comments: [{
            content: 'Comment content'
        }],
        date: '2018-09-11',
        resource: {
            // link: [
            //     {
            //         url: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            //         meta: {
            //             title: 'Here goes the article title and some copy attached to it | this is a link',
            //             thumbNail: 'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg'
            //         },
            //     },
            // ],
            videoUrl: [
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=0cGj4prWlFk&list=RDMMzdXiSlRrgWQ&index=3'
                },
                {
                    type: 'youtube',  //(youttube/else)
                    url: 'https://www.youtube.com/watch?v=0cGj4prWlFk&list=RDMMzdXiSlRrgWQ&index=3'
                },
            ],
            image: [
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
                'https://helpx.adobe.com/content/dam/help/en/stock/how-to/visual-reverse-image-search/jcr_content/main-pars/image/visual-reverse-image-search-v2_intro.jpg',
            ]
        },
        tagIds: ['string'],
        // like: {
        //     author: user_id,
        //     date: { type: Date, default: Date.now }
        // },
        // status: boolean
    },
]
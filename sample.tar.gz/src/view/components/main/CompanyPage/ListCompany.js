import React from 'react';

const ListCompany = (props) => {
    return (
        <div>
            
        </div>
    );
};

export default ListCompany;
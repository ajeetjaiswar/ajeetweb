import React from 'react';

const Reply = () => {
    return (
        <>
            <div className="reply-user-name">
                <h4>Username</h4>
            </div>
            <div className="comments">
                
            </div>
        </>
    );
};

export default Reply;
import React from 'react';

const ReplyHeader = () => {
    return (
        <div className="responses">
            <label>4 Responses</label>
        </div>
    );
};

export default ReplyHeader;
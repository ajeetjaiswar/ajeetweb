import React from 'react';

const Description = () => {
    return (
        <div className="text">
            <p>Lorem ipsum, or lipsum as it is sometimes known, is dummy text</p>
        </div>
    );
};

export default Description;
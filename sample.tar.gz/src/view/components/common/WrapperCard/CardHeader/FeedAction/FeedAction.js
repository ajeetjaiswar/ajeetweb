import React from 'react';

const FeedAction = () => {
    return (
        <div className="actions">
            <i className="kool-more"></i>
        </div>
    );
};

export default FeedAction;
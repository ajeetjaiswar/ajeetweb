import React from 'react';

const ProfileDetail = () => {
    return (
        <>
            <div className="profile-detail">
                <h4 className="mb-auto">Anindita Guha</h4>
                <label className=" mt-auto">HR Head</label>
            </div>
            
        </>
    );
};

export default ProfileDetail;
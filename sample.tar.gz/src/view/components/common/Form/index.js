import InputBox from './InputBox/InputBox'

export{
    InputBox
}
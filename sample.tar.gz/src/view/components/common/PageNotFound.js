import React from 'react';

export const PageNotFound = (props) => {

    return (
        <div>
            Page Not found
        </div>
    );
}

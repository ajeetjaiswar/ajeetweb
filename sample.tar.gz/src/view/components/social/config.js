export default {
    facebook: "517510855484467", //Facebook App Id
    linkedin :"81b7fmw2sadg0h", // LinkedIn Client Id
    google  : "827187596456-mcgm67jb9fag78f6mq3vjj9lt1pj0huv.apps.googleusercontent.com" //Google client id  
}

import Home from './main/Home/Home'
import AskAndAnswer from './main/Ask&Answer/Ask&Answer'
import Company from './main/CompanyPage/Company'
import CompanyDetail from './main/CompanyPage/CompanyDetail/CompanyDetail'
import AboutUs from './main/AboutUs/AboutUs'


export{
    Home,
    AskAndAnswer,
    Company,
    CompanyDetail,
    AboutUs
}

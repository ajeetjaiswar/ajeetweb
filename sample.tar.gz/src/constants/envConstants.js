export default {
    development: 'development',
    dev: 'dev',
    staging: 'staging',
    stag: 'stag',
    production: 'production',
    prod: 'prod',
    localhost: 'localhost',
    local: 'local'
}
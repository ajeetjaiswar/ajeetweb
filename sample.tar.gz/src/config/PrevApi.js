import setting from './settings'

export default [
    setting.api.prevUrl + 'common/getTrending',
    setting.api.prevUrl + 'companies',
    setting.api.prevUrl + 'common/notifyMe',
    setting.api.prevUrl + 'companies/searchedCompanies',
    setting.api.prevUrl + 'companies/company/'
];


import setting from './settings'

export default [
    setting.api.url + "user/login",
    setting.api.url + "user/logout",
    setting.api.url + "user/signUp",
    setting.api.url + "user/emailExists",
    setting.api.url + "user/forgotPassword",
    setting.api.url + "user/resetPassword",
    setting.api.url + "user/verifyEmail",
    setting.api.url + "user/linkedinData",
];

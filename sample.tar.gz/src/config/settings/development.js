export default {
    api: {
        url: 'https://ttkk-backend-dev.herokuapp.com/koolkanya/api/v1/',
        prevUrl:'https://koolkanya-backend-development.herokuapp.com/',
        mode: 'cors'
    }
}

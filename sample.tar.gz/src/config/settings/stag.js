export default {
    api: {
        url: 'https://ttkk-backend.herokuapp.com/koolkanya/api/v1/',
        mode: 'cors',
        prevUrl:'https://api.koolkanya.com/',
    }
}
